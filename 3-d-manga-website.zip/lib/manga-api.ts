// ---- Types ----

export interface MangaResult {
  id: string
  title: string
  image: string
  description?: string
  genres?: string[]
  status?: string
}

export interface MangaSearchResponse {
  results: MangaResult[]
  total: number
  hasNextPage: boolean
}

export interface MangaChapter {
  id: string
  title: string
  chapter: string | null
  volume: string | null
  releaseDate: string | null
}

export interface MangaInfo {
  id: string
  title: string
  altTitles?: string[]
  genres?: string[]
  image: string
  description?: string
  status?: string
  year?: number
  chapters: MangaChapter[]
}

export interface ChapterPage {
  page: number
  img: string
}

// ---- Helpers ----

const MANGADEX = "https://api.mangadex.org"

function getCoverUrl(mangaId: string, fileName: string, size: "256" | "512" = "512"): string {
  return `https://uploads.mangadex.org/covers/${mangaId}/${fileName}.${size}.jpg`
}

function getTitle(attributes: Record<string, unknown>): string {
  const titleMap = attributes.title as Record<string, string> | undefined
  if (!titleMap) return "Unknown"
  return titleMap.en || titleMap["ja-ro"] || titleMap.ja || Object.values(titleMap)[0] || "Unknown"
}

function getDescription(attributes: Record<string, unknown>): string {
  const descMap = attributes.description as Record<string, string> | undefined
  if (!descMap) return ""
  return descMap.en || Object.values(descMap)[0] || ""
}

function extractCoverFileName(relationships: Array<{ type: string; attributes?: Record<string, unknown> }>): string {
  const cover = relationships.find((r) => r.type === "cover_art")
  if (!cover?.attributes?.fileName) return ""
  return cover.attributes.fileName as string
}

interface MangaDexMangaData {
  id: string
  attributes: Record<string, unknown>
  relationships: Array<{ type: string; id: string; attributes?: Record<string, unknown> }>
}

function transformMangaData(manga: MangaDexMangaData): MangaResult {
  const coverFile = extractCoverFileName(manga.relationships)
  const tags = manga.attributes.tags as Array<{ attributes: { name: Record<string, string> } }> | undefined
  return {
    id: manga.id,
    title: getTitle(manga.attributes),
    image: coverFile ? getCoverUrl(manga.id, coverFile) : "",
    description: getDescription(manga.attributes),
    genres: tags?.map((t) => t.attributes.name.en).filter(Boolean) || [],
    status: (manga.attributes.status as string) || undefined,
  }
}

// ---- API functions (called from API routes on server) ----

export async function searchManga(query: string, limit = 20, offset = 0): Promise<MangaSearchResponse> {
  const params = new URLSearchParams()
  params.append("title", query)
  params.append("limit", String(limit))
  params.append("offset", String(offset))
  params.append("includes[]", "cover_art")
  params.append("contentRating[]", "safe")
  params.append("contentRating[]", "suggestive")
  params.append("order[relevance]", "desc")
  const res = await fetch(`${MANGADEX}/manga?${params}`)
  if (!res.ok) throw new Error(`MangaDex API error: ${res.status}`)
  const json = await res.json()
  return {
    results: json.data.map(transformMangaData),
    total: json.total,
    hasNextPage: offset + limit < json.total,
  }
}

export async function getPopularManga(limit = 20, offset = 0): Promise<MangaSearchResponse> {
  const params = new URLSearchParams()
  params.append("limit", String(limit))
  params.append("offset", String(offset))
  params.append("includes[]", "cover_art")
  params.append("contentRating[]", "safe")
  params.append("contentRating[]", "suggestive")
  params.append("order[followedCount]", "desc")
  const res = await fetch(`${MANGADEX}/manga?${params}`)
  if (!res.ok) throw new Error(`MangaDex API error: ${res.status}`)
  const json = await res.json()
  return {
    results: json.data.map(transformMangaData),
    total: json.total,
    hasNextPage: offset + limit < json.total,
  }
}

export async function getLatestUpdates(limit = 20, offset = 0): Promise<MangaSearchResponse> {
  const params = new URLSearchParams()
  params.append("limit", String(limit))
  params.append("offset", String(offset))
  params.append("includes[]", "cover_art")
  params.append("contentRating[]", "safe")
  params.append("contentRating[]", "suggestive")
  params.append("order[latestUploadedChapter]", "desc")
  const res = await fetch(`${MANGADEX}/manga?${params}`)
  if (!res.ok) throw new Error(`MangaDex API error: ${res.status}`)
  const json = await res.json()
  return {
    results: json.data.map(transformMangaData),
    total: json.total,
    hasNextPage: offset + limit < json.total,
  }
}

export async function getRecentManga(limit = 20, offset = 0): Promise<MangaSearchResponse> {
  const params = new URLSearchParams()
  params.append("limit", String(limit))
  params.append("offset", String(offset))
  params.append("includes[]", "cover_art")
  params.append("contentRating[]", "safe")
  params.append("contentRating[]", "suggestive")
  params.append("order[createdAt]", "desc")
  const res = await fetch(`${MANGADEX}/manga?${params}`)
  if (!res.ok) throw new Error(`MangaDex API error: ${res.status}`)
  const json = await res.json()
  return {
    results: json.data.map(transformMangaData),
    total: json.total,
    hasNextPage: offset + limit < json.total,
  }
}

export async function getMangaInfo(id: string): Promise<MangaInfo> {
  const res = await fetch(`${MANGADEX}/manga/${id}?includes[]=cover_art&includes[]=author&includes[]=artist`)
  if (!res.ok) throw new Error(`MangaDex API error: ${res.status}`)
  const json = await res.json()
  const manga = json.data
  const coverFile = extractCoverFileName(manga.relationships)
  const tags = manga.attributes.tags as Array<{ attributes: { name: Record<string, string> } }> | undefined
  const altTitlesList = manga.attributes.altTitles as Array<Record<string, string>> | undefined

  // Fetch English chapters first
  const chapParams = new URLSearchParams()
  chapParams.append("manga", id)
  chapParams.append("limit", "96")
  chapParams.append("offset", "0")
  chapParams.append("translatedLanguage[]", "en")
  chapParams.append("order[chapter]", "asc")
  chapParams.append("contentRating[]", "safe")
  chapParams.append("contentRating[]", "suggestive")
  chapParams.append("includes[]", "scanlation_group")
  let chapRes = await fetch(`${MANGADEX}/chapter?${chapParams}`)
  let chapJson = chapRes.ok ? await chapRes.json() : { data: [] }

  // If no English chapters found, try without language filter
  if (chapJson.data.length === 0) {
    const fallbackParams = new URLSearchParams()
    fallbackParams.append("manga", id)
    fallbackParams.append("limit", "96")
    fallbackParams.append("offset", "0")
    fallbackParams.append("order[chapter]", "asc")
    fallbackParams.append("contentRating[]", "safe")
    fallbackParams.append("contentRating[]", "suggestive")
    fallbackParams.append("includes[]", "scanlation_group")
    chapRes = await fetch(`${MANGADEX}/chapter?${fallbackParams}`)
    chapJson = chapRes.ok ? await chapRes.json() : { data: [] }
  }

  const chapters: MangaChapter[] = chapJson.data.map(
    (ch: { id: string; attributes: { title: string | null; chapter: string | null; volume: string | null; publishAt: string | null } }) => ({
      id: ch.id,
      title: ch.attributes.title || `Chapter ${ch.attributes.chapter || "?"}`,
      chapter: ch.attributes.chapter,
      volume: ch.attributes.volume,
      releaseDate: ch.attributes.publishAt,
    })
  )

  return {
    id: manga.id,
    title: getTitle(manga.attributes),
    altTitles: altTitlesList?.map((t) => Object.values(t)[0]).filter(Boolean) || [],
    genres: tags?.map((t) => t.attributes.name.en).filter(Boolean) || [],
    image: coverFile ? getCoverUrl(manga.id, coverFile) : "",
    description: getDescription(manga.attributes),
    status: manga.attributes.status || undefined,
    year: manga.attributes.year || undefined,
    chapters,
  }
}

export async function getChapterPages(chapterId: string): Promise<ChapterPage[]> {
  const res = await fetch(`${MANGADEX}/at-home/server/${chapterId}`)
  if (!res.ok) throw new Error(`MangaDex API error: ${res.status}`)
  const json = await res.json()
  const baseUrl = json.baseUrl
  const hash = json.chapter.hash
  const pages: string[] = json.chapter.data

  return pages.map((filename: string, i: number) => ({
    page: i + 1,
    img: `${baseUrl}/data/${hash}/${filename}`,
  }))
}

// ---- Image proxy (routes external images through our server) ----

export function proxyImage(url: string): string {
  if (!url) return ""
  return `/api/manga/image?url=${encodeURIComponent(url)}`
}

// ---- SWR helpers (client-side, point to our API routes) ----

export const fetcher = (url: string) =>
  fetch(url).then((r) => {
    if (!r.ok) throw new Error(`Fetch error: ${r.status}`)
    return r.json()
  })

export const getSearchUrl = (query: string, page = 1) =>
  `/api/manga/search?q=${encodeURIComponent(query)}&page=${page}`

export const getPopularUrl = (page = 1) => `/api/manga/popular?page=${page}`

export const getLatestUrl = (page = 1) => `/api/manga/latest?page=${page}`

export const getRecentUrl = (page = 1) => `/api/manga/recent?page=${page}`

export const getMangaInfoUrl = (id: string) => `/api/manga/info?id=${encodeURIComponent(id)}`

export const getChapterPagesUrl = (chapterId: string) => `/api/manga/read?id=${encodeURIComponent(chapterId)}`
